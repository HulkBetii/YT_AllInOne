# YouTube Authentication Guide

## 🔐 **YouTube Bot Check Issue**

YouTube sometimes requires authentication to confirm you're not a bot, especially when downloading multiple videos or accessing certain content.

## ✅ **Solutions**

### **Option 1: Use Browser Cookies (Recommended)**

The easiest way is to use cookies from your browser where you're already logged into YouTube:

```bash
# For Chrome
python -m src.app_cli get "YOUR_YOUTUBE_URL" --cookies-from-browser chrome

# For Edge
python -m src.app_cli get "YOUR_YOUTUBE_URL" --cookies-from-browser edge

# For Firefox
python -m src.app_cli get "YOUR_YOUTUBE_URL" --cookies-from-browser firefox
```

### **Option 2: Manual Cookies File**

If browser cookies don't work, you can export cookies manually:

1. Install a browser extension like "Get cookies.txt" or "Cookie Quick Manager"
2. Export cookies from YouTube to a `.txt` file
3. Use the cookies file:

```bash
python -m src.app_cli get "YOUR_YOUTUBE_URL" --cookies cookies.txt
```

### **Option 3: GUI App with Cookies**

In the GUI app:
1. Enter your YouTube URL
2. Use the cookies option in the advanced settings
3. The app will automatically handle authentication

## 🚨 **Error Messages**

When you see this error:
```
ERROR: [youtube] Sign in to confirm you're not a bot
```

**Solution**: Use one of the cookie methods above.

## 💡 **Tips**

- **Always use cookies** when downloading multiple videos
- **Keep cookies updated** - they expire after some time
- **Use the same browser** where you're logged into YouTube
- **Try different browsers** if one doesn't work

## 🔧 **Troubleshooting**

If cookies still don't work:
1. Make sure you're logged into YouTube in your browser
2. Try clearing browser cookies and logging in again
3. Check if YouTube has any region restrictions
4. Try using a VPN if you're in a restricted region

## 📱 **Supported Browsers**

- ✅ Chrome
- ✅ Edge  
- ✅ Firefox
- ✅ Safari (with manual cookie export)

---

**Note**: This app automatically detects authentication errors and provides helpful hints in Vietnamese to guide you through the process.
