# 🚀 YouTube All-in-One - Hướng dẫn cài đặt nhanh

## 📦 Cài đặt

### Phương pháp 1: Sử dụng file ZIP (Khuyến nghị)
1. Tải file `YouTube_AllinOne_App.zip`
2. Giải nén vào thư mục mong muốn
3. Chạy `Run_YouTube_AllinOne.bat` hoặc `YouTube_AllinOne.exe`

### Phương pháp 2: Chạy trực tiếp
1. Tải file `YouTube_AllinOne.exe`
2. Chạy trực tiếp file .exe

## 🎯 Sử dụng nhanh

1. **Khởi động ứng dụng**
   - Chạy `YouTube_AllinOne.exe`
   - Hoặc chạy `Run_YouTube_AllinOne.bat`

2. **Tải video**
   - Paste URL YouTube vào ô input
   - Chọn chất lượng: `best` (khuyến nghị)
   - Chọn thư mục lưu file
   - Bấm nút "Start"

3. **Ví dụ URL**
   ```
   https://www.youtube.com/watch?v=dQw4w9WgXcQ
   https://youtube.com/playlist?list=PLxxxxxxxx
   https://youtube.com/shorts/xxxxxxxxx
   ```

## ✨ Tính năng chính

- ✅ Tải video với chất lượng tốt nhất
- ✅ Tải thumbnail tự động
- ✅ Hỗ trợ playlist, channel, shorts
- ✅ Progress tracking real-time
- ✅ Pause/Resume/Cancel
- ✅ Giao diện đẹp và dễ sử dụng

## 🔧 Yêu cầu hệ thống

- Windows 10/11
- Không cần cài đặt Python
- Không cần cài đặt thêm software

## 📞 Hỗ trợ

Nếu gặp vấn đề:
1. Kiểm tra kết nối internet
2. Đảm bảo URL YouTube hợp lệ
3. Thử tải video khác để test

---
**Version**: 1.0  
**Build Date**: 2025-01-29  
**Size**: 43MB (GUI) + 30MB (CLI)
