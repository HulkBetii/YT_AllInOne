#!/usr/bin/env python3
"""
Simple build script for YouTube All-in-One
"""

import os
import subprocess
import sys

def build_simple():
    """Build với lệnh đơn giản"""
    
    print("🔨 Building YouTube All-in-One...")
    
    # Build GUI
    print("📱 Building GUI application...")
    cmd_gui = [
        "pyinstaller",
        "--onefile",
        "--windowed",
        "--icon", "favicon.png",
        "--name", "YouTube_AllinOne",
        "--add-data", "favicon.png;.",
        "src/app_gui.py"
    ]
    
    try:
        subprocess.run(cmd_gui, check=True)
        print("✅ GUI build thành công!")
    except subprocess.CalledProcessError as e:
        print(f"❌ GUI build lỗi: {e}")
        return False
    
    # Build CLI
    print("💻 Building CLI application...")
    cmd_cli = [
        "pyinstaller",
        "--onefile",
        "--icon", "favicon.png",
        "--name", "YouTube_AllinOne_CLI",
        "--add-data", "favicon.png;.",
        "src/app_cli.py"
    ]
    
    try:
        subprocess.run(cmd_cli, check=True)
        print("✅ CLI build thành công!")
    except subprocess.CalledProcessError as e:
        print(f"❌ CLI build lỗi: {e}")
        return False
    
    return True

if __name__ == "__main__":
    print("🚀 YouTube All-in-One Simple Builder")
    print("=" * 40)
    
    if build_simple():
        print("\n🎉 Build thành công!")
        print("📁 Files trong thư mục 'dist':")
        print("   - YouTube_AllinOne.exe (GUI)")
        print("   - YouTube_AllinOne_CLI.exe (CLI)")
    else:
        print("\n💥 Build thất bại!")
        sys.exit(1)
