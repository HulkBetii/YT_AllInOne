from PySide6.QtWidgets import QWidget


class PlaceholderWidget(QWidget):
    def __init__(self) -> None:
        super().__init__()

